import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  szamok:string[]=[]
  vizsgaltSzam!:number
  visszajelzoUzenet!:string

  EredmenyMentes(){
    let oszto:number=0
    for(let i=1;i<=this.vizsgaltSzam;i++){
      if(this.vizsgaltSzam%i==0){
        oszto++
      }
    }
    if(oszto==2){
      this.visszajelzoUzenet=`${this.vizsgaltSzam} prím szám`
    }
    else{
      this.visszajelzoUzenet=`${this.vizsgaltSzam} NEM prím szám`
    }

    this.szamok.push(this.visszajelzoUzenet)

  }

}
